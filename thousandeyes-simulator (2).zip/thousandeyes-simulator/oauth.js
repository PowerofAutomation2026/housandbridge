'use strict';
/**
 * OAuth 2.0 routes for the ThousandEyes API simulator.
 *
 * Implements:
 *   GET  /oauth/authorize  - shows consent page, redirects with code
 *   POST /oauth/token      - exchanges code or refresh_token for access_token
 *   GET  /admin/oauth-clients   (admin) - list registered OAuth apps
 *   POST /admin/oauth-clients   (admin) - register a new OAuth app
 *
 * Tokens issued here are stored in the same `tokens` table the bearer-auth
 * middleware checks, so they work seamlessly with every /v7/* endpoint.
 */

const express = require('express');
const crypto = require('crypto');
const { db, nowIso } = require('./db');

const router = express.Router();
router.use(express.urlencoded({ extended: true }));
router.use(express.json());

// In-memory store for authorization codes (short-lived, 10 min)
const authCodes = new Map();
// Map refresh_token -> { clientId, userEmail, scope }
const refreshTokens = new Map();

function genToken(prefix) {
  return prefix + '-' + crypto.randomBytes(24).toString('hex');
}

/**
 * Seed a default OAuth client on startup so users have one to copy values from.
 * Called from server.js after seedIfEmpty().
 */
function seedDefaultOAuthClient() {
  const existing = db.prepare('SELECT * FROM oauth_clients WHERE client_id = ?').get('powerplatform-default');
  if (existing) return existing;

  const client = {
    client_id: 'powerplatform-default',
    client_secret: 'te-sim-secret-' + crypto.randomBytes(16).toString('hex'),
    client_name: 'Power Platform Default',
    redirect_uris: JSON.stringify([
      'https://global.consent.azure-apim.net/redirect',
      'https://global.consent.azure-apim.net/redirect/cisco-thousandeyes',
      'http://localhost/oauth-callback'
    ]),
    scopes: 'read write',
    created_date: nowIso()
  };

  db.prepare(`INSERT INTO oauth_clients (client_id, client_secret, client_name, redirect_uris, scopes, created_date)
              VALUES (?, ?, ?, ?, ?, ?)`)
    .run(client.client_id, client.client_secret, client.client_name, client.redirect_uris, client.scopes, client.created_date);

  console.log('[OAUTH] Seeded default client:');
  console.log('         client_id     = ' + client.client_id);
  console.log('         client_secret = ' + client.client_secret);
  return client;
}

// ---------------------------------------------------------------
// GET /oauth/authorize
// ---------------------------------------------------------------
router.get('/authorize', (req, res) => {
  const { client_id, redirect_uri, response_type, scope, state } = req.query;

  if (!client_id || !redirect_uri || response_type !== 'code') {
    return res.status(400).send(errorPage('Missing required parameters', 'Need client_id, redirect_uri, response_type=code'));
  }

  const client = db.prepare('SELECT * FROM oauth_clients WHERE client_id = ?').get(client_id);
  if (!client) {
    return res.status(400).send(errorPage('Invalid client', 'Unknown client_id: ' + client_id));
  }

  // For development convenience, auto-approve and immediately redirect with code.
  // (Real ThousandEyes shows a consent screen — we simulate that with a brief auto-approval page.)
  const code = genToken('te-code');
  authCodes.set(code, {
    clientId: client_id,
    redirectUri: redirect_uri,
    scope: scope || 'read',
    userEmail: 'kerolos@simulator.local',
    expiresAt: Date.now() + 10 * 60 * 1000
  });

  const sep = redirect_uri.includes('?') ? '&' : '?';
  const finalUrl = `${redirect_uri}${sep}code=${encodeURIComponent(code)}` + (state ? `&state=${encodeURIComponent(state)}` : '');

  res.send(consentPage(client.client_name, scope || 'read', finalUrl));
});

// ---------------------------------------------------------------
// POST /oauth/token
// ---------------------------------------------------------------
router.post('/token', (req, res) => {
  // Power Platform may send credentials in Basic auth header OR in body
  let clientId = req.body.client_id;
  let clientSecret = req.body.client_secret;
  const authHeader = req.headers.authorization || '';
  if (authHeader.startsWith('Basic ')) {
    try {
      const decoded = Buffer.from(authHeader.slice(6), 'base64').toString('utf8');
      const [id, secret] = decoded.split(':');
      clientId = clientId || id;
      clientSecret = clientSecret || secret;
    } catch (e) { /* ignore */ }
  }

  if (!clientId) {
    return res.status(400).json({ error: 'invalid_request', error_description: 'client_id missing' });
  }

  const client = db.prepare('SELECT * FROM oauth_clients WHERE client_id = ?').get(clientId);
  if (!client) {
    return res.status(401).json({ error: 'invalid_client', error_description: 'Unknown client_id' });
  }
  if (client.client_secret !== clientSecret) {
    return res.status(401).json({ error: 'invalid_client', error_description: 'client_secret mismatch' });
  }

  const grantType = req.body.grant_type;

  // ---- Authorization Code grant ----
  if (grantType === 'authorization_code') {
    const code = req.body.code;
    const entry = authCodes.get(code);
    if (!entry) {
      return res.status(400).json({ error: 'invalid_grant', error_description: 'Code not found or already used' });
    }
    if (entry.expiresAt < Date.now()) {
      authCodes.delete(code);
      return res.status(400).json({ error: 'invalid_grant', error_description: 'Code expired' });
    }
    if (entry.clientId !== clientId) {
      return res.status(400).json({ error: 'invalid_grant', error_description: 'Code was not issued to this client' });
    }
    authCodes.delete(code);

    return issueTokenResponse(res, {
      clientId,
      userEmail: entry.userEmail,
      scope: entry.scope
    });
  }

  // ---- Refresh Token grant ----
  if (grantType === 'refresh_token') {
    const refresh = req.body.refresh_token;
    const entry = refreshTokens.get(refresh);
    if (!entry) {
      return res.status(400).json({ error: 'invalid_grant', error_description: 'Invalid refresh_token' });
    }
    return issueTokenResponse(res, {
      clientId: entry.clientId,
      userEmail: entry.userEmail,
      scope: entry.scope
    });
  }

  // ---- Client Credentials grant (for service-to-service flows) ----
  if (grantType === 'client_credentials') {
    return issueTokenResponse(res, {
      clientId,
      userEmail: 'service-account@' + clientId,
      scope: req.body.scope || 'read'
    });
  }

  return res.status(400).json({
    error: 'unsupported_grant_type',
    error_description: 'Supported grant_types: authorization_code, refresh_token, client_credentials'
  });
});

function issueTokenResponse(res, { clientId, userEmail, scope }) {
  const accessToken = genToken('te-oauth');
  const refreshToken = genToken('te-refresh');
  const expiresIn = 3600; // 1 hour

  // Insert access token into tokens table — bearer-auth middleware reuses it
  db.prepare(`INSERT INTO tokens (token, user_email, account_group_id, description, created_date)
              VALUES (?, ?, ?, ?, ?)`)
    .run(accessToken, userEmail, 'aid-1', 'OAuth token for ' + clientId, nowIso());

  refreshTokens.set(refreshToken, { clientId, userEmail, scope });

  res.json({
    access_token: accessToken,
    token_type: 'Bearer',
    expires_in: expiresIn,
    refresh_token: refreshToken,
    scope
  });
}

// ---------------------------------------------------------------
// Pretty HTML pages
// ---------------------------------------------------------------
function consentPage(appName, scope, redirectUrl) {
  return `<!DOCTYPE html>
<html><head><title>Authorize ${appName}</title>
<style>
body{font-family:-apple-system,Segoe UI,sans-serif;background:#0d0d12;color:#e4e4e7;margin:0;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px}
.card{background:#1c1f2b;border:1px solid #2a2e3a;border-radius:12px;padding:36px;max-width:440px;text-align:center}
h1{margin:0 0 8px;color:#00d4ff}
p{color:#a0a0a8;line-height:1.6}
.scope{background:#0d0d12;padding:8px 14px;border-radius:6px;display:inline-block;margin:8px;font-family:Menlo,monospace;color:#ff9100}
.btn{background:#00d4ff;color:#0d0d12;padding:12px 32px;border:none;border-radius:6px;font-weight:700;cursor:pointer;font-size:15px;text-decoration:none;display:inline-block;margin-top:20px}
.btn:hover{background:#00b8d4}
.auto{color:#9be17b;font-size:13px;margin-top:12px}
</style></head>
<body><div class="card">
<h1>∞ ThousandEyes Simulator</h1>
<p><strong>${appName}</strong> is requesting access to your simulated ThousandEyes account.</p>
<p>Permissions requested:</p>
<div><span class="scope">${scope}</span></div>
<a href="${redirectUrl}" class="btn">Authorize →</a>
<p class="auto">⚡ Auto-approving in 1.5s for development convenience...</p>
<script>setTimeout(()=>{window.location='${redirectUrl}'},1500);</script>
</div></body></html>`;
}

function errorPage(title, msg) {
  return `<!DOCTYPE html><html><head><title>${title}</title>
<style>body{font-family:sans-serif;background:#0d0d12;color:#e4e4e7;display:flex;align-items:center;justify-content:center;min-height:100vh}
.card{background:#1c1f2b;padding:30px;border-radius:8px;border-left:6px solid #e24b4a;max-width:480px}
h1{color:#e24b4a;margin:0 0 8px}</style></head>
<body><div class="card"><h1>⚠ ${title}</h1><p>${msg}</p></div></body></html>`;
}

// ---------------------------------------------------------------
// Admin endpoints
// ---------------------------------------------------------------
function adminAuth(req, res, next) {
  const key = req.headers['x-admin-key'];
  if (key !== (process.env.ADMIN_KEY || 'simulator-admin')) {
    return res.status(401).json({ error: 'admin auth required' });
  }
  next();
}

const adminRouter = express.Router();

adminRouter.get('/oauth-clients', adminAuth, (req, res) => {
  const clients = db.prepare('SELECT * FROM oauth_clients').all();
  res.json(clients.map(c => ({
    clientId: c.client_id,
    clientSecret: c.client_secret,
    clientName: c.client_name,
    redirectUris: JSON.parse(c.redirect_uris || '[]'),
    scopes: c.scopes,
    createdDate: c.created_date
  })));
});

adminRouter.post('/oauth-clients', adminAuth, (req, res) => {
  const id = req.body.clientId || 'app-' + crypto.randomBytes(4).toString('hex');
  const secret = 'te-sim-secret-' + crypto.randomBytes(16).toString('hex');
  db.prepare(`INSERT INTO oauth_clients (client_id, client_secret, client_name, redirect_uris, scopes, created_date)
              VALUES (?, ?, ?, ?, ?, ?)`)
    .run(id, secret,
         req.body.clientName || id,
         JSON.stringify(req.body.redirectUris || ['https://global.consent.azure-apim.net/redirect']),
         req.body.scopes || 'read write',
         nowIso());
  res.status(201).json({ clientId: id, clientSecret: secret });
});

module.exports = { router, adminRouter, seedDefaultOAuthClient };
