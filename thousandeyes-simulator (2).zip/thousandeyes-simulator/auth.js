'use strict';
const { db, nowIso } = require('./db');

/**
 * Multi-mode authentication middleware.
 *
 * Accepts any of:
 *   1. Authorization: Bearer <token>          (the classic ThousandEyes way)
 *   2. Authorization: Basic <base64>           (username:password - password IS the token)
 *   3. X-API-Key: <token>                      (custom header, simple API Key style)
 *   4. ?api_key=<token>                        (query string, last resort)
 *
 * This means the simulator works with EVERY Power Platform auth dropdown choice:
 *   - "No authentication"        - use X-API-Key in the flow's HTTP action
 *   - "Basic authentication"     - connector handles base64, password = token
 *   - "API Key in header"        - if dropdown shows it, use X-API-Key
 *   - OAuth 2.0                  - routes via oauth.js, issues Bearer tokens
 *
 * The token validated is the same `tokens` table either way.
 */
function bearerAuth(req, res, next) {
  let token = null;
  let authMethod = null;

  const authHeader = req.headers.authorization || '';

  // 1. Bearer token
  const bearerMatch = authHeader.match(/^Bearer\s+(.+)$/i);
  if (bearerMatch) {
    token = bearerMatch[1].trim();
    authMethod = 'bearer';
  }

  // 2. Basic auth (decode, use password as token)
  if (!token) {
    const basicMatch = authHeader.match(/^Basic\s+(.+)$/i);
    if (basicMatch) {
      try {
        const decoded = Buffer.from(basicMatch[1].trim(), 'base64').toString('utf8');
        const colonIdx = decoded.indexOf(':');
        if (colonIdx > -1) {
          token = decoded.substring(colonIdx + 1);
          authMethod = 'basic';
        }
      } catch (e) { /* fall through to 401 */ }
    }
  }

  // 3. X-API-Key header
  if (!token) {
    const apiKeyHeader = req.headers['x-api-key'];
    if (apiKeyHeader) {
      token = String(apiKeyHeader).trim();
      authMethod = 'x-api-key';
    }
  }

  // 4. ?api_key= query param
  if (!token && req.query.api_key) {
    token = String(req.query.api_key).trim();
    authMethod = 'query';
  }

  if (!token) {
    return res.status(401).json({
      type: 'https://developer.cisco.com/docs/thousandeyes/errors/unauthorized',
      title: 'Unauthorized',
      status: 401,
      detail: 'Missing credentials. Use one of: "Authorization: Bearer <token>", "Authorization: Basic <base64-of-anyuser:token>", "X-API-Key: <token>", or "?api_key=<token>".'
    });
  }

  const row = db.prepare('SELECT * FROM tokens WHERE token = ?').get(token);
  if (!row) {
    return res.status(401).json({
      type: 'https://developer.cisco.com/docs/thousandeyes/errors/unauthorized',
      title: 'Unauthorized',
      status: 401,
      detail: 'Invalid token (auth method: ' + authMethod + '). Get a fresh one from /admin/tokens or the simulator banner.'
    });
  }

  const aidQuery = req.query.aid;
  req.context = {
    token,
    authMethod,
    userEmail: row.user_email,
    aid: aidQuery || row.account_group_id,
    audit(req, res, startedAt) {
      db.prepare('INSERT INTO audit_log (timestamp, user_email, method, endpoint, status_code, response_time_ms) VALUES (?, ?, ?, ?, ?, ?)')
        .run(nowIso(), row.user_email, req.method, req.originalUrl, res.statusCode, Date.now() - startedAt);
    }
  };
  next();
}

module.exports = { bearerAuth };
