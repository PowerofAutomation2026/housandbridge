'use strict';
/**
 * ThousandEyes API Simulator – In-Memory Store
 * Author: Kerolos – Power of Automation Blog
 *
 * Pure-JS Map-based store. No native deps.
 * Re-seeds on every boot with realistic enterprise mock data.
 *
 * Exposes a `db` object with a tiny prepared-statement-like API
 * (prepare(sql).run/get/all) that emulates the bits of better-sqlite3
 * used in routes — so the route code reads naturally.
 */

const { v4: uuidv4 } = require('uuid');
const fs = require('fs');
const path = require('path');

const PERSIST_FILE = process.env.PERSIST_FILE;

const tables = {
  tokens: new Map(),
  account_groups: new Map(),
  agents: new Map(),
  tests: new Map(),
  test_results: [],
  alerts: new Map(),
  alert_rules: new Map(),
  suppression_windows: new Map(),
  dashboards: new Map(),
  internet_insights: new Map(),
  oauth_clients: new Map(),
  audit_log: []
};

function nowIso() { return new Date().toISOString(); }
function randomBetween(min, max) { return Math.random() * (max - min) + min; }
function randomInt(min, max) { return Math.floor(randomBetween(min, max + 1)); }
function pick(arr) { return arr[randomInt(0, arr.length - 1)]; }

const pkMap = {
  tokens: 'token', account_groups: 'aid', agents: 'agent_id',
  tests: 'test_id', alerts: 'alert_id', alert_rules: 'rule_id',
  suppression_windows: 'window_id', dashboards: 'dashboard_id',
  internet_insights: 'outage_id'
};

function allRows(table) {
  const t = tables[table];
  return Array.isArray(t) ? t : Array.from(t.values());
}

function addRow(table, row) {
  const t = tables[table];
  if (Array.isArray(t)) { t.push(row); return; }
  const pk = pkMap[table];
  t.set(row[pk], row);
}

function prepare(sql) {
  const s = sql.replace(/\s+/g, ' ').trim();

  let m = s.match(/^INSERT INTO (\w+)\s*\(([^)]+)\)\s*VALUES\s*\(([^)]+)\)$/i);
  if (m) {
    const table = m[1], cols = m[2].split(',').map(c => c.trim());
    return { run: (...vals) => { const row = {}; cols.forEach((c, i) => row[c] = vals[i]); addRow(table, row); } };
  }

  m = s.match(/^SELECT (.+?) FROM (\w+)(?:\s+(?:LEFT\s+)?JOIN\s+\w+\s+\w+\s+ON\s+[^W]+?)?(?:\s+WHERE\s+(.+?))?(?:\s+ORDER BY\s+(.+?))?(?:\s+LIMIT\s+(\d+))?$/i);
  if (m) {
    const [, what, table, whereStr, orderStr, limitStr] = m;
    return {
      get: (...args) => runSelect(table, what, whereStr, orderStr, limitStr, args)[0] || null,
      all: (...args) => runSelect(table, what, whereStr, orderStr, limitStr, args)
    };
  }

  m = s.match(/^UPDATE (\w+)\s+SET\s+(.+?)\s+WHERE\s+(.+?)$/i);
  if (m) {
    const [, table, setPart, wherePart] = m;
    const setExprs = setPart.split(',').map(e => e.trim());
    const setCols = setExprs.map(e => e.split('=')[0].trim());
    const whereCol = wherePart.split('=')[0].trim();
    return {
      run: (...vals) => {
        const whereVal = vals[vals.length - 1];
        for (const row of allRows(table)) {
          if (row[whereCol] === whereVal) {
            setCols.forEach((c, i) => {
              if (vals[i] !== null && vals[i] !== undefined) row[c] = vals[i];
            });
          }
        }
      }
    };
  }

  m = s.match(/^DELETE FROM (\w+)\s+WHERE\s+(\w+)\s*=\s*\?$/i);
  if (m) {
    const [, table, col] = m;
    return {
      run: (val) => {
        const t = tables[table];
        if (t instanceof Map) for (const [k, row] of t) if (row[col] === val) t.delete(k);
      }
    };
  }

  throw new Error('Unsupported SQL: ' + sql);
}

function runSelect(table, what, whereStr, orderStr, limitStr, args) {
  let rows = allRows(table);

  if (whereStr) {
    const conditions = whereStr.split(/\s+AND\s+/i).map(c => c.trim());
    // Pre-bind each condition to its arg index BEFORE iterating rows
    const bound = conditions.map((cond, condIdx) => {
      const cm = cond.match(/^([\w.]+)\s*(=|>=|<=|>|<|!=)\s*\?$/);
      if (!cm) return null;
      let [, col, op] = cm;
      col = col.replace(/^[a-z_]+\./, '');
      return { col, op, val: args[condIdx] };
    });
    rows = rows.filter(row => bound.every(b => {
      if (!b) return true;
      const v = row[b.col];
      switch (b.op) {
        case '=':  return v === b.val;
        case '!=': return v !== b.val;
        case '>=': return v >= b.val;
        case '<=': return v <= b.val;
        case '>':  return v > b.val;
        case '<':  return v < b.val;
      }
    }));
  }

  if (orderStr) {
    const [orderColRaw, dir] = orderStr.split(/\s+/);
    const orderCol = orderColRaw.replace(/^[a-z_]+\./, '');
    const mult = (dir || 'ASC').toUpperCase() === 'DESC' ? -1 : 1;
    rows.sort((a, b) => {
      if (a[orderCol] < b[orderCol]) return -1 * mult;
      if (a[orderCol] > b[orderCol]) return 1 * mult;
      return 0;
    });
  }

  if (limitStr) rows = rows.slice(0, parseInt(limitStr, 10));

  if (/COUNT\s*\(\s*\*\s*\)/i.test(what)) return [{ c: rows.length }];

  return rows;
}

const db = { prepare };

function seedIfEmpty() {
  if (tables.agents.size > 0) return;

  if (PERSIST_FILE && fs.existsSync(PERSIST_FILE)) {
    try {
      const snap = JSON.parse(fs.readFileSync(PERSIST_FILE, 'utf8'));
      Object.keys(snap).forEach(t => {
        if (Array.isArray(tables[t])) tables[t] = snap[t];
        else tables[t] = new Map(Object.entries(snap[t]));
      });
      console.log('[DB] Restored from snapshot:', PERSIST_FILE);
      return;
    } catch (e) {
      console.error('[DB] Failed to restore snapshot, reseeding:', e.message);
    }
  }

  console.log('[DB] Seeding initial data...');

  const aid = '1551';
  tables.account_groups.set(aid, {
    aid, account_group_name: 'PNC Bank - InfraSec', organization_name: 'PNC Bank',
    is_current: 1, is_default_account_group: 1
  });
  tables.account_groups.set('1552', {
    aid: '1552', account_group_name: 'PNC Bank - Cloud', organization_name: 'PNC Bank',
    is_current: 0, is_default_account_group: 0
  });

  const seedToken = 'te-sim-' + uuidv4();
  tables.tokens.set(seedToken, {
    token: seedToken, user_email: 'kerolos@powerofautomation.dev',
    account_group_id: aid, created_at: nowIso()
  });

  const agentDefs = [
    { name: 'San Francisco, CA', type: 'Cloud', country: 'US', loc: 'San Francisco Bay Area', lat: 37.7749, lng: -122.4194 },
    { name: 'New York, NY',     type: 'Cloud', country: 'US', loc: 'New York Metropolitan Area', lat: 40.7128, lng: -74.0060 },
    { name: 'Washington, DC',   type: 'Cloud', country: 'US', loc: 'Washington Metro', lat: 38.9072, lng: -77.0369 },
    { name: 'Dallas, TX',       type: 'Cloud', country: 'US', loc: 'Dallas-Fort Worth Metroplex', lat: 32.7767, lng: -96.7970 },
    { name: 'Toronto, Canada',  type: 'Cloud', country: 'CA', loc: 'Greater Toronto Area', lat: 43.6532, lng: -79.3832 },
    { name: 'London, UK',       type: 'Cloud', country: 'GB', loc: 'Greater London', lat: 51.5074, lng: -0.1278 },
    { name: 'Frankfurt, Germany', type: 'Cloud', country: 'DE', loc: 'Frankfurt Rhein-Main', lat: 50.1109, lng: 8.6821 },
    { name: 'Belgrade, Serbia', type: 'Cloud', country: 'RS', loc: 'Belgrade', lat: 44.7866, lng: 20.4489 },
    { name: 'Singapore',        type: 'Cloud', country: 'SG', loc: 'Singapore', lat: 1.3521,  lng: 103.8198 },
    { name: 'Tokyo, Japan',     type: 'Cloud', country: 'JP', loc: 'Greater Tokyo Area', lat: 35.6762, lng: 139.6503 },
    { name: 'Sydney, Australia',type: 'Cloud', country: 'AU', loc: 'Sydney', lat: -33.8688, lng: 151.2093 },
    { name: 'São Paulo, Brazil',type: 'Cloud', country: 'BR', loc: 'São Paulo Metropolitan Area', lat: -23.5505, lng: -46.6333 },
    { name: 'PNC-DC-CoreSwitch-01', type: 'Enterprise', country: 'US', loc: 'Pittsburgh, PA Data Center', lat: 40.4406, lng: -79.9959 },
    { name: 'PNC-DC-Edge-Router-02', type: 'Enterprise', country: 'US', loc: 'Cleveland, OH Data Center', lat: 41.4993, lng: -81.6944 }
  ];
  agentDefs.forEach((a, i) => {
    const id = String(281474976710700 + i);
    tables.agents.set(id, {
      agent_id: id, agent_name: a.name, agent_type: a.type, country_id: a.country,
      location: a.loc,
      ip_addresses: JSON.stringify([
        `64.29.${randomInt(130, 145)}.${randomInt(1, 254)}`,
        `64.29.${randomInt(130, 145)}.${randomInt(1, 254)}`
      ]),
      enabled: 1, latitude: a.lat, longitude: a.lng,
      created_date: nowIso(), agent_state: 'online'
    });
  });

  const testDefs = [
    { name: 'PNC Online Banking - Login Page',  type: 'http-server', url: 'https://www.pnc.com/login', interval: 60 },
    { name: 'PNC Mobile API Gateway',           type: 'http-server', url: 'https://api.pnc.com/v2/health', interval: 60 },
    { name: 'PNC Wire Transfer Endpoint',       type: 'http-server', url: 'https://wire.pnc.com', interval: 120 },
    { name: 'Microsoft 365 - Outlook',          type: 'http-server', url: 'https://outlook.office365.com', interval: 300 },
    { name: 'Microsoft Teams - Status',         type: 'http-server', url: 'https://teams.microsoft.com', interval: 300 },
    { name: 'SharePoint Online - powerappsfargo2022', type: 'http-server', url: 'https://powerappsfargo2022.sharepoint.com', interval: 60 },
    { name: 'Salesforce - Login',               type: 'page-load',   url: 'https://login.salesforce.com', interval: 300 },
    { name: 'Azure AD Login',                   type: 'http-server', url: 'https://login.microsoftonline.com', interval: 60 },
    { name: 'DNS Resolution - 8.8.8.8',         type: 'dns-server',  url: '8.8.8.8', interval: 300 },
    { name: 'BGP Route Monitoring - PNC AS',    type: 'bgp',         url: 'AS17350', interval: 120 },
    { name: 'PNC Data Center - Network Latency', type: 'agent-to-agent', url: '', interval: 60 },
    { name: 'Cisco Webex Audio Quality',        type: 'voice',       url: 'webex.cisco.com', interval: 300 }
  ];

  const cloudAgentIds = Array.from(tables.agents.values()).filter(a => a.agent_type === 'Cloud').map(a => a.agent_id);

  testDefs.forEach((t, i) => {
    const tid = String(987600 + i);
    const selectedAgents = [...cloudAgentIds].sort(() => Math.random() - 0.5).slice(0, randomInt(3, 6));
    tables.tests.set(tid, {
      test_id: tid, test_name: t.name, type: t.type, interval: t.interval,
      enabled: 1, alerts_enabled: 1, server: t.url, url: t.url, port: null,
      description: `Monitors ${t.name}`, created_date: nowIso(), modified_date: nowIso(),
      agent_ids: JSON.stringify(selectedAgents),
      config_json: JSON.stringify({ protocol: 'TCP', httpVersion: 2 })
    });
  });

  const alertRuleDefs = [
    { name: 'HTTP Availability < 100%', type: 'http-server', expr: '((availability < 100%))', severity: 'major' },
    { name: 'HTTP Response Time > 2000ms', type: 'http-server', expr: '((responseTime >= 2000 ms))', severity: 'minor' },
    { name: 'Network Loss > 5%', type: 'end-to-end-server', expr: '((loss >= 5%))', severity: 'critical' },
    { name: 'High Latency > 200ms', type: 'end-to-end-server', expr: '((latency >= 200 ms))', severity: 'major' },
    { name: 'DNS Resolution Failed', type: 'dns-server', expr: '((resolutionTime >= 1000 ms))', severity: 'critical' },
    { name: 'BGP Prefix Withdrawn', type: 'bgp', expr: '((reachability < 100%))', severity: 'critical' }
  ];
  alertRuleDefs.forEach((r, i) => {
    const rid = String(127090 + i);
    tables.alert_rules.set(rid, {
      rule_id: rid, rule_name: r.name, expression: r.expr,
      alert_type: r.type, severity: r.severity,
      notify_on_clear: 1, is_default: 0,
      rounds_violating_required: 2, rounds_violating_out_of: 3,
      minimum_sources: 1, created_date: nowIso()
    });
  });

  const allTests = Array.from(tables.tests.values());
  const allRules = Array.from(tables.alert_rules.values());

  for (let i = 0; i < 3; i++) {
    const rule = pick(allRules);
    const compatible = allTests.filter(t => t.type === rule.alert_type || rule.alert_type === 'end-to-end-server');
    const test = compatible.length ? pick(compatible) : pick(allTests);
    const startMinutesAgo = randomInt(5, 240);
    const aid_ = uuidv4();
    tables.alerts.set(aid_, {
      alert_id: aid_, rule_id: rule.rule_id, rule_name: rule.rule_name,
      test_id: test.test_id, test_name: test.test_name,
      alert_type: rule.alert_type, severity: rule.severity, state: 'trigger',
      start_date: new Date(Date.now() - startMinutesAgo * 60_000).toISOString(),
      end_date: null,
      permalink: `https://app.thousandeyes.com/alerts/list/?alertId=${aid_}`,
      details_json: JSON.stringify([
        { id: '3000', name: 'San Francisco', state: 'trigger', type: 'cea_agent',
          start: { metrics: `responseTime: ${randomInt(2100, 5000)} ms` }}
      ]),
      active_sources: randomInt(1, 3), violation_count: randomInt(2, 10)
    });
  }
  for (let i = 0; i < 8; i++) {
    const rule = pick(allRules); const test = pick(allTests);
    const startMinutesAgo = randomInt(60, 60 * 24 * 7);
    const durationMinutes = randomInt(5, 120);
    const aid_ = uuidv4();
    tables.alerts.set(aid_, {
      alert_id: aid_, rule_id: rule.rule_id, rule_name: rule.rule_name,
      test_id: test.test_id, test_name: test.test_name,
      alert_type: rule.alert_type, severity: rule.severity, state: 'clear',
      start_date: new Date(Date.now() - startMinutesAgo * 60_000).toISOString(),
      end_date: new Date(Date.now() - (startMinutesAgo - durationMinutes) * 60_000).toISOString(),
      permalink: `https://app.thousandeyes.com/alerts/list/?alertId=${aid_}`,
      details_json: '[]',
      active_sources: 0, violation_count: randomInt(1, 5)
    });
  }

  // Test results (recent rounds)
  allTests.forEach(test => {
    const tAgents = JSON.parse(test.agent_ids);
    const rounds = Math.floor(3600 / test.interval);
    for (let r = 0; r < rounds; r++) {
      const roundDate = new Date(Date.now() - (rounds - r) * test.interval * 1000);
      tAgents.forEach(agentId => {
        const m = generateMetrics(test.type);
        tables.test_results.push({
          result_id: uuidv4(), test_id: test.test_id, agent_id: agentId,
          round_id: Math.floor(roundDate.getTime() / 1000),
          date: roundDate.toISOString(),
          metrics_json: JSON.stringify(m)
        });
      });
    }
  });

  const did1 = uuidv4();
  tables.dashboards.set(did1, {
    dashboard_id: did1, title: 'PNC Banking - Critical Apps',
    description: 'Top-level health of customer-facing apps',
    is_default_for_user: 1, is_private: 0, created_date: nowIso(), modified_date: nowIso(),
    widgets_json: JSON.stringify([
      { type: 'test-metric', metric: 'availability', testIds: [allTests[0]?.test_id], title: 'Login Availability' },
      { type: 'alert-list', title: 'Active Alerts' }
    ])
  });
  const did2 = uuidv4();
  tables.dashboards.set(did2, {
    dashboard_id: did2, title: 'Microsoft 365 Health',
    description: 'M365 service connectivity from all branches',
    is_default_for_user: 0, is_private: 0, created_date: nowIso(), modified_date: nowIso(),
    widgets_json: '[]'
  });

  const wid = uuidv4();
  tables.suppression_windows.set(wid, {
    window_id: wid, window_name: 'Sunday Maintenance',
    description: 'Weekly 2-hour maintenance window',
    start_date: '2026-05-17T02:00:00Z', end_date: '2026-05-17T04:00:00Z',
    recurrence: 'WEEKLY', enabled: 1
  });

  const oid1 = uuidv4();
  tables.internet_insights.set(oid1, {
    outage_id: oid1, outage_type: 'network',
    provider_name: null, application_name: null,
    network_name: 'Comcast Cable Communications',
    affected_locations: JSON.stringify(['Philadelphia, PA', 'Boston, MA']),
    start_date: new Date(Date.now() - 30 * 60_000).toISOString(),
    end_date: null,
    affected_test_ids: JSON.stringify([allTests[0]?.test_id])
  });
  const oid2 = uuidv4();
  tables.internet_insights.set(oid2, {
    outage_id: oid2, outage_type: 'application',
    provider_name: null, application_name: 'Microsoft Office 365', network_name: null,
    affected_locations: JSON.stringify(['Global']),
    start_date: new Date(Date.now() - 2 * 60 * 60_000).toISOString(),
    end_date: new Date(Date.now() - 30 * 60_000).toISOString(),
    affected_test_ids: '[]'
  });

  console.log('[DB] Seed complete.');
}

function generateMetrics(testType) {
  const isOutage = Math.random() < 0.05;
  switch (testType) {
    case 'http-server':
    case 'page-load':
      return {
        availability: isOutage ? randomBetween(50, 80) : randomBetween(98, 100),
        responseTime: isOutage ? randomInt(2500, 8000) : randomInt(80, 600),
        connectTime: randomInt(20, 200), dnsTime: randomInt(5, 80),
        sslTime: randomInt(50, 250), waitTime: randomInt(40, 400),
        totalTime: randomInt(200, 1200),
        responseCode: isOutage ? pick([500, 502, 503, 504]) : 200,
        throughput: randomInt(1000, 50000)
      };
    case 'agent-to-server':
    case 'agent-to-agent':
    case 'end-to-end-server':
      return {
        loss: isOutage ? randomBetween(5, 25) : randomBetween(0, 0.5),
        latency: isOutage ? randomBetween(200, 600) : randomBetween(8, 80),
        jitter: randomBetween(0.5, 8),
        avgLatency: randomBetween(8, 80),
        minLatency: randomBetween(5, 40),
        maxLatency: randomBetween(20, 120),
        mos: randomBetween(3.8, 4.5)
      };
    case 'dns-server':
      return {
        resolutionTime: isOutage ? randomInt(1500, 4000) : randomInt(15, 200),
        availability: isOutage ? randomBetween(70, 90) : 100,
        mappedAnswers: ['142.250.190.78', '142.250.190.46']
      };
    case 'bgp':
      return {
        reachability: isOutage ? randomBetween(70, 95) : 100,
        pathChanges: randomInt(0, 3), updates: randomInt(0, 8)
      };
    case 'voice':
      return {
        mos: randomBetween(3.8, 4.5), jitter: randomBetween(0.5, 15),
        latency: randomBetween(20, 120), loss: randomBetween(0, 2),
        rfactor: randomBetween(70, 90)
      };
    default: return {};
  }
}

function saveSnapshot() {
  if (!PERSIST_FILE) return;
  const snap = {};
  Object.keys(tables).forEach(t => {
    if (Array.isArray(tables[t])) snap[t] = tables[t];
    else snap[t] = Object.fromEntries(tables[t]);
  });
  fs.mkdirSync(path.dirname(PERSIST_FILE), { recursive: true });
  fs.writeFileSync(PERSIST_FILE, JSON.stringify(snap));
}
if (PERSIST_FILE) setInterval(saveSnapshot, 60_000);

module.exports = {
  db, tables, seedIfEmpty, generateMetrics,
  nowIso, randomInt, randomBetween, pick
};
