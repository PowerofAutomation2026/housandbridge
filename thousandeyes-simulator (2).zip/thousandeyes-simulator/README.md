# ThousandEyes API Simulator

A faithful local replica of the Cisco ThousandEyes API v7. Use it to develop
and test Power Platform custom connectors, Power Automate flows, Power Apps,
and Copilot Studio agents **without burning real ThousandEyes API quota**.

By Kerolos · Power of Automation Blog

---

## Quick start

```bash
# 1. Install Node.js 20+ from https://nodejs.org

# 2. Install dependencies
cd simulator
npm install

# 3. Start the server
npm start
```

On boot, the simulator prints a banner with your seed bearer token. Save it —
you'll paste it into the Power Platform custom connector.

```
╔════════════════════════════════════════════════════════════════╗
║   ThousandEyes API Simulator – v1.0                            ║
║   Listening on:   http://localhost:4000                        ║
║   API base:       http://localhost:4000/v7                     ║
║   Web Console:    http://localhost:4000/                       ║
║                                                                ║
║   Seed bearer token (use this in custom connector):            ║
║   te-sim-a1b2c3d4-e5f6-7890-abcd-ef1234567890                  ║
╚════════════════════════════════════════════════════════════════╝
```

Open `http://localhost:4000/` in your browser for the admin console.

---

## Configuration (`.env`)

Copy `.env.example` to `.env` and customize:

```ini
PORT=4000
HOST=0.0.0.0                       # bind to all interfaces (required for gateway/LAN access)
ADMIN_KEY=simulator-admin          # admin endpoint key
PERSIST_FILE=                      # optional: path to a JSON snapshot file for persistence
```

**Important:** For Power Platform on-premises data gateway access from another
machine on your LAN, set `HOST=0.0.0.0`. Default localhost binding only allows
local connections.

---

## What's seeded

When the simulator boots empty, it auto-seeds:

- **14 agents** — 12 global Cloud agents (San Francisco, NYC, London, etc.) +
  2 PNC Enterprise agents
- **12 tests** — PNC Online Banking, Wire Transfer, M365 Outlook, SharePoint,
  Salesforce login, BGP monitor, DNS server, voice/SIP, plus more
- **11 alerts** — 3 currently active (one critical, one major, one minor) + 8
  recently cleared
- **6 alert rules** — covering availability, response time, latency, loss
- **2 dashboards** — "PNC Banking - Critical Apps" + "Microsoft 365 Health"
- **4 BGP monitors** — Equinix Ashburn, PCCW Singapore, etc.
- **Suppression windows** + Internet Insights outages
- **60 minutes of historical test results** per test (latency, loss, jitter,
  response time, availability)

Every 15 seconds the simulator generates a new round of test results to keep
data flowing for your dashboards.

---

## API endpoints

Base URL: `http://localhost:4000/v7`

Auth: `Authorization: Bearer <token>` header on every request.

| Endpoint | Description |
|----------|-------------|
| `GET /v7/agents` | List all agents |
| `GET /v7/agents/{id}` | Get agent detail |
| `GET /v7/tests` | List all tests |
| `GET /v7/tests/{type}` | List tests by type (http-server, page-load, etc.) |
| `POST /v7/tests/{type}` | Create a new test |
| `GET /v7/tests/{type}/{id}` | Get test detail |
| `PUT /v7/tests/{type}/{id}` | Update a test |
| `DELETE /v7/tests/{type}/{id}` | Delete a test |
| `POST /v7/tests/{type}/instant` | Run instant test |
| `GET /v7/test-results/{id}/network` | Network metrics |
| `GET /v7/test-results/{id}/http-server` | HTTP metrics |
| `GET /v7/test-results/{id}/path-vis` | Path visualization |
| `GET /v7/alerts?state=active` | List alerts |
| `GET /v7/alerts/{id}` | Get alert |
| `GET /v7/alerts/rules` | List alert rules |
| `GET /v7/alerts/suppression-windows` | List suppression windows |
| `GET /v7/dashboards` | List dashboards |
| `GET /v7/internet-insights/catalog-providers` | Catalog providers |
| `POST /v7/internet-insights/outages/filter` | Filter outages |
| `GET /v7/bgp-monitors` | List BGP monitors |
| `GET /v7/usage` | Account usage / quota |
| `GET /v7/tags` | List tags |
| `GET /v7/account-groups` | Account groups |
| `GET /v7/users/current` | Current user |

Use the `aid=<account-group-id>` query param to scope to a specific account
group (just like the real ThousandEyes API).

Use `window=60m` (or `24h`, `7d`, etc.) on test-results endpoints.

---

## Admin endpoints

For tooling/automation. Require `X-Admin-Key: simulator-admin` header.

| Endpoint | Description |
|----------|-------------|
| `GET /admin/stats` | Live counters and recent API calls |
| `GET /admin/tokens` | List all bearer tokens |
| `POST /admin/tokens` | Generate a new bearer token |
| `DELETE /admin/tokens/:token` | Revoke a token |
| `POST /admin/trigger-alert` | Fire a fresh active alert (useful for testing flows) |
| `POST /admin/reset` | Reset all data and re-seed |

---

## Real-time WebSocket

Subscribe to live events at `ws://localhost:4000/ws`. Messages:

```json
{ "type": "api.request", "method": "GET", "path": "/v7/agents", "status": 200 }
{ "type": "alert.triggered", "alertId": "187654321", "severity": "major" }
{ "type": "test.result", "testId": "987600", "agentId": "281474976710700" }
```

The admin console uses this for live updates.

---

## Docker (alternative to npm)

```bash
docker compose up -d
```

Listens on port 4000 same as npm. Use a volume mount for `PERSIST_FILE` if you
want data to survive container restarts.

---

## File structure

```
simulator/
├── server.js          Main Express app + WebSocket + routes
├── db.js              In-memory store with SQL-like API + seed data
├── auth.js            Bearer token middleware
├── package.json       Dependencies (express, ws, uuid)
├── Dockerfile         Container build
├── docker-compose.yml One-command deployment
├── .env.example       Configuration template
└── public/
    └── index.html     Admin web console (dark-themed)
```

---

## Migrating to real ThousandEyes

The simulator faithfully replicates the API surface, so flows you build
against it work against the real API with one change: swap the connector's
host from your simulator URL to `api.thousandeyes.com`, and the bearer token
from the simulator's seed token to a real one from
**Manage → Account Settings → Users and Roles → Profile → User API Tokens**.

---

## License

MIT — use it, fork it, ship it.

Not affiliated with Cisco. "Cisco ThousandEyes" is a trademark of Cisco
Systems, Inc.

— Built by Kerolos · powerofautomation2025.blogspot.com
