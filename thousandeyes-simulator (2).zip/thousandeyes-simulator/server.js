'use strict';
/**
 * ThousandEyes API v7 Simulator
 * --------------------------------
 *  Replicates the major endpoint surface of api.thousandeyes.com/v7
 *  so you can develop & test Power Platform custom connectors
 *  without consuming real API quota.
 *
 *  Author: Kerolos (Power of Automation Blog)
 *  Base path: /v7/...
 *  Auth: Authorization: Bearer <token>
 *  Default seed token printed on first boot. You can also create new ones in the web UI.
 */

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const http = require('http');
const WebSocket = require('ws');

const { db, seedIfEmpty, generateMetrics, nowIso, randomInt, pick } = require('./db');
const { bearerAuth } = require('./auth');
const { router: oauthRouter, adminRouter: oauthAdminRouter, seedDefaultOAuthClient } = require('./oauth');

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(morgan('tiny'));
app.use(express.static(path.join(__dirname, 'public')));

// OAuth 2.0 endpoints (no auth required — they ARE the auth)
app.use('/oauth', oauthRouter);
app.use('/admin', oauthAdminRouter);

// Audit timing
app.use((req, res, next) => {
  res._startedAt = Date.now();
  res.on('finish', () => req.context?.audit?.(req, res, res._startedAt));
  next();
});

// ---------- HEALTH & ROOT ----------
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'thousandeyes-simulator', timestamp: nowIso(), version: '1.0.0' });
});

// ----------------------------------------------------------------------
//  v7 API ROUTES (all require bearer auth)
// ----------------------------------------------------------------------
const api = express.Router();
api.use(bearerAuth);

// HAL+JSON helper
function withLinks(self, extras = {}) {
  return {
    self: { href: `https://api.thousandeyes.com${self}` },
    ...extras
  };
}

// Pagination helper
function paginate(items, req, baseUrl) {
  const limit = Math.min(parseInt(req.query.max || '100', 10), 1000);
  const cursor = parseInt(req.query.cursor || '0', 10);
  const slice = items.slice(cursor, cursor + limit);
  const _links = {
    self: { href: `${baseUrl}?max=${limit}&cursor=${cursor}` }
  };
  if (cursor + limit < items.length) {
    _links.next = { href: `${baseUrl}?max=${limit}&cursor=${cursor + limit}` };
  }
  if (cursor > 0) {
    _links.previous = { href: `${baseUrl}?max=${limit}&cursor=${Math.max(0, cursor - limit)}` };
  }
  return { slice, _links };
}

// ============== ACCOUNT GROUPS ==============
api.get('/account-groups', (req, res) => {
  const rows = db.prepare('SELECT * FROM account_groups').all();
  res.json({
    accountGroups: rows.map(r => ({
      aid: r.aid,
      accountGroupName: r.account_group_name,
      organizationName: r.organization_name,
      isCurrentAccountGroup: !!r.is_current,
      isDefaultAccountGroup: !!r.is_default_account_group
    })),
    _links: withLinks('/v7/account-groups')
  });
});

api.get('/account-groups/:aid', (req, res) => {
  const r = db.prepare('SELECT * FROM account_groups WHERE aid = ?').get(req.params.aid);
  if (!r) return res.status(404).json({ status: 404, title: 'Not Found' });
  res.json({
    aid: r.aid,
    accountGroupName: r.account_group_name,
    organizationName: r.organization_name,
    _links: withLinks(`/v7/account-groups/${r.aid}`)
  });
});

// ============== USERS ==============
api.get('/users/current', (req, res) => {
  res.json({
    uid: '12345',
    name: 'Kerolos (Simulator)',
    email: req.context.userEmail,
    loginAccountGroup: { aid: req.context.aid, accountGroupName: 'PNC Bank - InfraSec' },
    accountGroupRoles: [
      { accountGroup: { aid: req.context.aid }, roles: [{ name: 'Organization Admin', roleId: '57' }] }
    ],
    _links: withLinks('/v7/users/current')
  });
});

// ============== AGENTS ==============
api.get('/agents', (req, res) => {
  const all = db.prepare('SELECT * FROM agents WHERE enabled = 1').all();
  const filtered = req.query.agentTypes
    ? all.filter(a => req.query.agentTypes.split(',').map(s => s.trim().toLowerCase()).includes(a.agent_type.toLowerCase()))
    : all;

  const { slice, _links } = paginate(filtered, req, `https://api.thousandeyes.com/v7/agents`);

  res.json({
    agents: slice.map(a => ({
      agentId: a.agent_id,
      agentName: a.agent_name,
      agentType: a.agent_type,
      countryId: a.country_id,
      location: a.location,
      ipAddresses: JSON.parse(a.ip_addresses || '[]'),
      enabled: !!a.enabled,
      targetOnly: 0,
      agentState: a.agent_state,
      coordinates: { latitude: a.latitude, longitude: a.longitude },
      createdDate: a.created_date,
      _links: withLinks(`/v7/agents/${a.agent_id}`)
    })),
    _links
  });
});

api.get('/agents/:agentId', (req, res) => {
  const a = db.prepare('SELECT * FROM agents WHERE agent_id = ?').get(req.params.agentId);
  if (!a) return res.status(404).json({ status: 404, title: 'Not Found' });
  res.json({
    agentId: a.agent_id,
    agentName: a.agent_name,
    agentType: a.agent_type,
    countryId: a.country_id,
    location: a.location,
    ipAddresses: JSON.parse(a.ip_addresses || '[]'),
    enabled: !!a.enabled,
    coordinates: { latitude: a.latitude, longitude: a.longitude },
    createdDate: a.created_date,
    _links: withLinks(`/v7/agents/${a.agent_id}`)
  });
});

api.put('/agents/:agentId', (req, res) => {
  const a = db.prepare('SELECT * FROM agents WHERE agent_id = ?').get(req.params.agentId);
  if (!a) return res.status(404).json({ status: 404, title: 'Not Found' });
  if (req.body.agentName) db.prepare('UPDATE agents SET agent_name = ? WHERE agent_id = ?').run(req.body.agentName, a.agent_id);
  if (typeof req.body.enabled === 'boolean') db.prepare('UPDATE agents SET enabled = ? WHERE agent_id = ?').run(req.body.enabled ? 1 : 0, a.agent_id);
  res.json({ ...a, ...req.body });
});

// ============== TESTS ==============
api.get('/tests', (req, res) => {
  const tests = db.prepare('SELECT * FROM tests').all();
  const { slice, _links } = paginate(tests, req, `https://api.thousandeyes.com/v7/tests`);
  res.json({
    tests: slice.map(formatTest),
    _links
  });
});

// Filter by type: /v7/tests/{type}
api.get('/tests/:type', (req, res) => {
  const t = req.params.type;
  if (['agent-to-server','agent-to-agent','bgp','http-server','page-load','web-transactions','ftp-server','dns-server','dns-trace','dnssec','sip-server','voice','api'].indexOf(t) === -1) {
    // single test id lookup
    const single = db.prepare('SELECT * FROM tests WHERE test_id = ?').get(t);
    if (single) return res.json(formatTest(single));
    return res.status(404).json({ status: 404, title: 'Not Found' });
  }
  const tests = db.prepare('SELECT * FROM tests WHERE type = ?').all(t);
  res.json({ tests: tests.map(formatTest), _links: withLinks(`/v7/tests/${t}`) });
});

api.get('/tests/:type/:testId', (req, res) => {
  const t = db.prepare('SELECT * FROM tests WHERE test_id = ?').get(req.params.testId);
  if (!t) return res.status(404).json({ status: 404, title: 'Not Found' });
  res.json(formatTest(t));
});

api.post('/tests/:type', (req, res) => {
  const tid = String(900000 + randomInt(1000, 9999));
  const body = req.body;
  db.prepare(`INSERT INTO tests
    (test_id, test_name, type, interval, enabled, alerts_enabled, server, url, description, created_date, modified_date, agent_ids, config_json)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(
      tid, body.testName, req.params.type, body.interval || 60,
      body.enabled === false ? 0 : 1,
      body.alertsEnabled === false ? 0 : 1,
      body.server || '', body.url || body.server || '', body.description || '',
      nowIso(), nowIso(),
      JSON.stringify((body.agents || []).map(a => a.agentId)),
      JSON.stringify(body)
    );
  const created = db.prepare('SELECT * FROM tests WHERE test_id = ?').get(tid);
  res.status(201).json(formatTest(created));
});

api.put('/tests/:type/:testId', (req, res) => {
  const t = db.prepare('SELECT * FROM tests WHERE test_id = ?').get(req.params.testId);
  if (!t) return res.status(404).json({ status: 404, title: 'Not Found' });
  const body = req.body;
  db.prepare(`UPDATE tests SET test_name = COALESCE(?, test_name),
              interval = COALESCE(?, interval),
              enabled = COALESCE(?, enabled),
              alerts_enabled = COALESCE(?, alerts_enabled),
              modified_date = ?
              WHERE test_id = ?`)
    .run(body.testName ?? null,
         body.interval ?? null,
         body.enabled === undefined ? null : (body.enabled ? 1 : 0),
         body.alertsEnabled === undefined ? null : (body.alertsEnabled ? 1 : 0),
         nowIso(), req.params.testId);
  const updated = db.prepare('SELECT * FROM tests WHERE test_id = ?').get(req.params.testId);
  res.json(formatTest(updated));
});

api.delete('/tests/:type/:testId', (req, res) => {
  db.prepare('DELETE FROM tests WHERE test_id = ?').run(req.params.testId);
  res.status(204).send();
});

function formatTest(t) {
  if (!t) return null;
  return {
    testId: t.test_id,
    testName: t.test_name,
    type: t.type,
    interval: t.interval,
    enabled: !!t.enabled,
    alertsEnabled: !!t.alerts_enabled,
    server: t.server,
    url: t.url,
    description: t.description,
    createdDate: t.created_date,
    modifiedDate: t.modified_date,
    agents: JSON.parse(t.agent_ids || '[]').map(id => ({ agentId: id })),
    _links: withLinks(`/v7/tests/${t.type}/${t.test_id}`, {
      testResults: [
        { href: `https://api.thousandeyes.com/v7/test-results/${t.test_id}/network` },
        { href: `https://api.thousandeyes.com/v7/test-results/${t.test_id}/http-server` }
      ]
    })
  };
}

// ============== TEST RESULTS ==============
function parseWindow(req) {
  const w = req.query.window;
  if (!w) return { fromDate: new Date(Date.now() - 60 * 60_000), toDate: new Date() };
  const m = String(w).match(/^(\d+)([smhdw])$/);
  if (!m) return { fromDate: new Date(Date.now() - 60 * 60_000), toDate: new Date() };
  const n = parseInt(m[1], 10);
  const unit = m[2];
  const factor = { s: 1000, m: 60_000, h: 3600_000, d: 86_400_000, w: 604_800_000 }[unit];
  return { fromDate: new Date(Date.now() - n * factor), toDate: new Date() };
}

api.get('/test-results/:testId/network', (req, res) => {
  const t = db.prepare('SELECT * FROM tests WHERE test_id = ?').get(req.params.testId);
  if (!t) return res.status(404).json({ status: 404, title: 'Not Found' });
  const { fromDate, toDate } = parseWindow(req);
  const fromIso = fromDate.toISOString();
  const toIso = toDate.toISOString();
  const all = db.prepare('SELECT * FROM test_results WHERE test_id = ?').all(req.params.testId);
  const filtered = all
    .filter(r => r.date >= fromIso && r.date <= toIso)
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, 1000);
  res.json({
    test: formatTest(t),
    startDate: fromIso,
    endDate: toIso,
    results: filtered.map(r => {
      const agent = db.prepare('SELECT * FROM agents WHERE agent_id = ?').get(r.agent_id) || {};
      return {
        agent: {
          agentId: r.agent_id,
          agentName: agent.agent_name,
          countryId: agent.country_id,
          location: agent.location
        },
        roundId: r.round_id,
        date: r.date,
        ...JSON.parse(r.metrics_json)
      };
    }),
    _links: withLinks(`/v7/test-results/${req.params.testId}/network`)
  });
});

api.get('/test-results/:testId/http-server', (req, res) => {
  const t = db.prepare('SELECT * FROM tests WHERE test_id = ?').get(req.params.testId);
  if (!t) return res.status(404).json({ status: 404, title: 'Not Found' });
  const { fromDate, toDate } = parseWindow(req);
  const fromIso = fromDate.toISOString();
  const toIso = toDate.toISOString();
  const all = db.prepare('SELECT * FROM test_results WHERE test_id = ?').all(req.params.testId);
  const filtered = all
    .filter(r => r.date >= fromIso && r.date <= toIso)
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, 1000);
  res.json({
    test: formatTest(t),
    results: filtered.map(r => {
      const agent = db.prepare('SELECT * FROM agents WHERE agent_id = ?').get(r.agent_id) || {};
      return {
        agent: { agentId: r.agent_id, agentName: agent.agent_name },
        roundId: r.round_id,
        date: r.date,
        ...JSON.parse(r.metrics_json)
      };
    }),
    _links: withLinks(`/v7/test-results/${req.params.testId}/http-server`)
  });
});

api.get('/test-results/:testId/path-vis', (req, res) => {
  const t = db.prepare('SELECT * FROM tests WHERE test_id = ?').get(req.params.testId);
  if (!t) return res.status(404).json({ status: 404, title: 'Not Found' });
  res.json({
    test: formatTest(t),
    results: JSON.parse(t.agent_ids).slice(0, 3).map(agentId => ({
      agent: { agentId },
      pathTraces: [{
        pathId: uuidv4(),
        hops: Array.from({ length: randomInt(6, 14) }, (_, i) => ({
          ttl: i + 1,
          ipAddress: `10.${randomInt(0,255)}.${randomInt(0,255)}.${randomInt(1,254)}`,
          networkName: `AS${randomInt(100, 64000)}`,
          rtt: randomInt(5, 200),
          asn: randomInt(100, 64000)
        }))
      }]
    })),
    _links: withLinks(`/v7/test-results/${req.params.testId}/path-vis`)
  });
});

// ============== ALERTS ==============
// IMPORTANT: declare sub-routes (/alerts/rules, /alerts/suppression-windows) BEFORE /alerts/:alertId

// ============== ALERT RULES ==============
api.get('/alerts/rules', (req, res) => {
  const rules = db.prepare('SELECT * FROM alert_rules').all();
  res.json({
    alertRules: rules.map(r => ({
      ruleId: r.rule_id,
      ruleName: r.rule_name,
      expression: r.expression,
      alertType: r.alert_type,
      severity: r.severity,
      notifyOnClear: !!r.notify_on_clear,
      isDefault: !!r.is_default,
      roundsViolatingRequired: r.rounds_violating_required,
      roundsViolatingOutOf: r.rounds_violating_out_of,
      minimumSources: r.minimum_sources,
      _links: withLinks(`/v7/alerts/rules/${r.rule_id}`)
    })),
    _links: withLinks('/v7/alerts/rules')
  });
});

api.get('/alerts/rules/:ruleId', (req, res) => {
  const r = db.prepare('SELECT * FROM alert_rules WHERE rule_id = ?').get(req.params.ruleId);
  if (!r) return res.status(404).json({ status: 404, title: 'Not Found' });
  res.json({
    ruleId: r.rule_id, ruleName: r.rule_name, expression: r.expression,
    alertType: r.alert_type, severity: r.severity,
    notifyOnClear: !!r.notify_on_clear, isDefault: !!r.is_default,
    _links: withLinks(`/v7/alerts/rules/${r.rule_id}`)
  });
});

api.post('/alerts/rules', (req, res) => {
  const id = String(140000 + randomInt(100, 999));
  const b = req.body;
  db.prepare(`INSERT INTO alert_rules (rule_id, rule_name, expression, alert_type, severity, notify_on_clear, is_default, rounds_violating_required, rounds_violating_out_of, minimum_sources, created_date)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(id, b.ruleName, b.expression || '', b.alertType, b.severity || 'major',
         b.notifyOnClear ? 1 : 0, b.isDefault ? 1 : 0,
         b.roundsViolatingRequired || 1, b.roundsViolatingOutOf || 1,
         b.minimumSources || 1, nowIso());
  res.status(201).json({ ruleId: id, ...b });
});

api.delete('/alerts/rules/:ruleId', (req, res) => {
  db.prepare('DELETE FROM alert_rules WHERE rule_id = ?').run(req.params.ruleId);
  res.status(204).send();
});

// ============== ALERT SUPPRESSION WINDOWS ==============
api.get('/alerts/suppression-windows', (req, res) => {
  const ws = db.prepare('SELECT * FROM suppression_windows').all();
  res.json({
    alertSuppressionWindows: ws.map(w => ({
      id: w.window_id, name: w.window_name, description: w.description,
      startDate: w.start_date, endDate: w.end_date,
      recurrence: w.recurrence, enabled: !!w.enabled
    })),
    _links: withLinks('/v7/alerts/suppression-windows')
  });
});

api.post('/alerts/suppression-windows', (req, res) => {
  const id = uuidv4();
  const b = req.body;
  db.prepare(`INSERT INTO suppression_windows (window_id, window_name, description, start_date, end_date, recurrence, enabled) VALUES (?, ?, ?, ?, ?, ?, ?)`)
    .run(id, b.name, b.description || '', b.startDate, b.endDate || null, b.recurrence || null, b.enabled === false ? 0 : 1);
  res.status(201).json({ id, ...b });
});

api.delete('/alerts/suppression-windows/:id', (req, res) => {
  db.prepare('DELETE FROM suppression_windows WHERE window_id = ?').run(req.params.id);
  res.status(204).send();
});

// ============== ALERTS (LIST + DETAIL) ==============
api.get('/alerts', (req, res) => {
  const state = req.query.state;
  let alerts;
  if (state === 'active') {
    alerts = db.prepare("SELECT * FROM alerts WHERE state = ? ORDER BY start_date DESC").all('trigger');
  } else {
    alerts = db.prepare('SELECT * FROM alerts ORDER BY start_date DESC').all();
  }
  const { slice, _links } = paginate(alerts, req, `https://api.thousandeyes.com/v7/alerts`);
  res.json({
    alerts: slice.map(formatAlert),
    _links
  });
});

api.get('/alerts/:alertId', (req, res) => {
  const a = db.prepare('SELECT * FROM alerts WHERE alert_id = ?').get(req.params.alertId);
  if (!a) return res.status(404).json({ status: 404, title: 'Not Found' });
  res.json(formatAlert(a));
});

function formatAlert(a) {
  return {
    id: a.alert_id,
    ruleId: a.rule_id,
    ruleName: a.rule_name,
    testId: a.test_id,
    testName: a.test_name,
    alertType: a.alert_type,
    alertState: a.state,
    alertSeverity: a.severity,
    startDate: a.start_date,
    endDate: a.end_date,
    permalink: a.permalink,
    activeSources: a.active_sources,
    violationCount: a.violation_count,
    details: JSON.parse(a.details_json || '[]'),
    _links: withLinks(`/v7/alerts/${a.alert_id}`)
  };
}

// ============== DASHBOARDS ==============
api.get('/dashboards', (req, res) => {
  const rows = db.prepare('SELECT * FROM dashboards').all();
  res.json({
    dashboards: rows.map(r => ({
      dashboardId: r.dashboard_id, title: r.title, description: r.description,
      isDefaultForUser: !!r.is_default_for_user, isPrivate: !!r.is_private,
      createdDate: r.created_date, modifiedDate: r.modified_date,
      _links: withLinks(`/v7/dashboards/${r.dashboard_id}`)
    })),
    _links: withLinks('/v7/dashboards')
  });
});

api.get('/dashboards/:id', (req, res) => {
  const r = db.prepare('SELECT * FROM dashboards WHERE dashboard_id = ?').get(req.params.id);
  if (!r) return res.status(404).json({ status: 404, title: 'Not Found' });
  res.json({
    dashboardId: r.dashboard_id, title: r.title, description: r.description,
    widgets: JSON.parse(r.widgets_json || '[]'),
    _links: withLinks(`/v7/dashboards/${r.dashboard_id}`)
  });
});

// ============== INTERNET INSIGHTS ==============
api.get('/internet-insights/catalog-providers', (req, res) => {
  res.json({
    catalogProviders: [
      { id: 'aws', providerName: 'Amazon Web Services', providerType: 'iaas' },
      { id: 'azure', providerName: 'Microsoft Azure', providerType: 'iaas' },
      { id: 'gcp', providerName: 'Google Cloud', providerType: 'iaas' },
      { id: 'm365', providerName: 'Microsoft 365', providerType: 'saas' },
      { id: 'salesforce', providerName: 'Salesforce', providerType: 'saas' }
    ],
    _links: withLinks('/v7/internet-insights/catalog-providers')
  });
});

api.post('/internet-insights/outages/filter', (req, res) => {
  const rows = db.prepare('SELECT * FROM internet_insights').all();
  const outageType = req.body?.outageType || req.query.outageType;
  const filtered = outageType ? rows.filter(r => r.outage_type === outageType) : rows;
  res.json({
    networkOutages: filtered.filter(r => r.outage_type === 'network').map(formatOutage),
    applicationOutages: filtered.filter(r => r.outage_type === 'application').map(formatOutage),
    _links: withLinks('/v7/internet-insights/outages/filter')
  });
});

function formatOutage(o) {
  return {
    id: o.outage_id, outageType: o.outage_type,
    providerName: o.provider_name, applicationName: o.application_name,
    networkName: o.network_name,
    affectedLocations: JSON.parse(o.affected_locations || '[]'),
    startDate: o.start_date, endDate: o.end_date,
    affectedTestIds: JSON.parse(o.affected_test_ids || '[]')
  };
}

// ============== BGP MONITORS ==============
api.get('/bgp-monitors', (req, res) => {
  const monitors = [
    { monitorId: 1, monitorName: 'Equinix Ashburn', countryId: 'US', ipAddress: '206.126.236.21', monitorType: 'Public', network: 'Equinix (AS6461)' },
    { monitorId: 2, monitorName: 'PCCW Singapore', countryId: 'SG', ipAddress: '63.218.13.10', monitorType: 'Public', network: 'PCCW Global (AS3491)' },
    { monitorId: 3, monitorName: 'LINX London', countryId: 'GB', ipAddress: '195.66.224.179', monitorType: 'Public', network: 'LINX (AS8714)' },
    { monitorId: 4, monitorName: 'DE-CIX Frankfurt', countryId: 'DE', ipAddress: '80.81.192.176', monitorType: 'Public', network: 'DE-CIX (AS6695)' }
  ];
  res.json({ bgpMonitors: monitors, _links: withLinks('/v7/bgp-monitors') });
});

// ============== INSTANT TESTS ==============
api.post('/tests/:type/instant', (req, res) => {
  const tid = String(8000000 + randomInt(10000, 99999));
  res.status(201).json({
    testId: tid,
    testName: req.body.testName || 'Instant Test',
    type: req.params.type,
    server: req.body.server,
    _links: withLinks(`/v7/tests/${req.params.type}/${tid}`, {
      testResults: [
        { href: `https://api.thousandeyes.com/v7/test-results/${tid}/network` }
      ]
    })
  });
});

// ============== USAGE & QUOTA ==============
api.get('/usage', (req, res) => {
  res.json({
    quota: {
      cloudUnitsIncluded: 100000,
      cloudUnitsUsed: randomInt(40000, 80000),
      enterpriseUnitsIncluded: 50,
      enterpriseUnitsUsed: randomInt(20, 45),
      deviceAgentsIncluded: 100,
      deviceAgentsUsed: randomInt(10, 50),
      endpointAgentsIncluded: 500,
      endpointAgentsUsed: randomInt(100, 400)
    },
    _links: withLinks('/v7/usage')
  });
});

// ============== TAGS ==============
api.get('/tags', (req, res) => {
  res.json({
    tags: [
      { id: '1001', key: 'env', value: 'prod', assignmentType: 'test', color: '#FF6B35' },
      { id: '1002', key: 'env', value: 'staging', assignmentType: 'test', color: '#FFD23F' },
      { id: '1003', key: 'business-unit', value: 'retail-banking', assignmentType: 'test', color: '#06A77D' },
      { id: '1004', key: 'business-unit', value: 'wholesale', assignmentType: 'test', color: '#005B9F' }
    ],
    _links: withLinks('/v7/tags')
  });
});

// ============== INTEGRATIONS (Webhooks) ==============
api.get('/integrations/webhook-operations', (req, res) => {
  res.json({
    operations: [
      { id: 'wh-001', name: 'Send to Teams', type: 'custom-webhook', target: 'https://outlook.office.com/webhook/...' },
      { id: 'wh-002', name: 'Send to ServiceNow', type: 'custom-webhook', target: 'https://pnc.service-now.com/api/...' }
    ],
    _links: withLinks('/v7/integrations/webhook-operations')
  });
});

// Mount the API
app.use('/v7', api);

// ----------------------------------------------------------------------
//  ADMIN ENDPOINTS (used by web UI – auth via simple header)
// ----------------------------------------------------------------------
function adminAuth(req, res, next) {
  if (req.headers['x-admin-key'] === (process.env.ADMIN_KEY || 'simulator-admin')) return next();
  res.status(403).json({ error: 'Forbidden' });
}

app.get('/admin/tokens', adminAuth, (req, res) => {
  res.json(db.prepare('SELECT * FROM tokens').all());
});

app.post('/admin/tokens', adminAuth, (req, res) => {
  const t = 'te-sim-' + uuidv4();
  db.prepare('INSERT INTO tokens (token, user_email, account_group_id, created_at) VALUES (?, ?, ?, ?)')
    .run(t, req.body.email || 'sim-user@local', req.body.aid || '1551', nowIso());
  res.json({ token: t });
});

app.delete('/admin/tokens/:t', adminAuth, (req, res) => {
  db.prepare('DELETE FROM tokens WHERE token = ?').run(req.params.t);
  res.status(204).send();
});

app.get('/admin/stats', adminAuth, (req, res) => {
  const { tables } = require('./db');
  const recentCalls = [...tables.audit_log].reverse().slice(0, 20);
  res.json({
    agents: db.prepare('SELECT COUNT(*) FROM agents').get()?.c || 0,
    tests:  db.prepare('SELECT COUNT(*) FROM tests').get()?.c || 0,
    alerts: db.prepare('SELECT COUNT(*) FROM alerts').get()?.c || 0,
    activeAlerts: db.prepare("SELECT COUNT(*) FROM alerts WHERE state = ?").get('trigger')?.c || 0,
    apiCalls: tables.audit_log.length,
    recentCalls
  });
});

app.post('/admin/trigger-alert', adminAuth, (req, res) => {
  const tests = db.prepare('SELECT * FROM tests').all();
  const rules = db.prepare('SELECT * FROM alert_rules').all();
  const test = pick(tests); const rule = pick(rules);
  const alertId = uuidv4();
  db.prepare(`INSERT INTO alerts (alert_id, rule_id, rule_name, test_id, test_name, alert_type, severity, state, start_date, permalink, details_json, active_sources, violation_count)
              VALUES (?, ?, ?, ?, ?, ?, ?, 'trigger', ?, ?, ?, ?, ?)`)
    .run(alertId, rule.rule_id, rule.rule_name, test.test_id, test.test_name,
         rule.alert_type, rule.severity, nowIso(),
         `https://app.thousandeyes.com/alerts/list/?alertId=${alertId}`,
         JSON.stringify([]), 1, randomInt(2, 8));
  // broadcast over WS
  broadcast({ type: 'alert.triggered', alertId });
  res.json({ alertId });
});

// ----------------------------------------------------------------------
// WebSocket for real-time event push
// ----------------------------------------------------------------------
const server = http.createServer(app);
const wss = new WebSocket.Server({ server, path: '/ws' });

function broadcast(payload) {
  const data = JSON.stringify(payload);
  wss.clients.forEach(c => c.readyState === WebSocket.OPEN && c.send(data));
}

wss.on('connection', ws => {
  ws.send(JSON.stringify({ type: 'hello', message: 'ThousandEyes simulator stream connected' }));
});

// Generate new test results on the simulator's own clock
setInterval(() => {
  const tests = db.prepare('SELECT * FROM tests WHERE enabled = 1').all();
  if (!tests.length) return;
  const test = pick(tests);
  JSON.parse(test.agent_ids || '[]').forEach(agentId => {
    const m = generateMetrics(test.type);
    db.prepare(`INSERT INTO test_results (result_id, test_id, agent_id, round_id, date, metrics_json) VALUES (?, ?, ?, ?, ?, ?)`)
      .run(uuidv4(), test.test_id, agentId, Math.floor(Date.now()/1000), nowIso(), JSON.stringify(m));
  });
  broadcast({ type: 'test.result.new', testId: test.test_id });
}, 15000);

// Boot
seedIfEmpty();
const oauthClient = seedDefaultOAuthClient();
server.listen(PORT, () => {
  const tokens = db.prepare('SELECT token FROM tokens LIMIT 1').all();
  const token = tokens[0]?.token || 'NO_TOKEN';
  // For Basic auth: base64("user:" + token)
  const basicB64 = Buffer.from('user:' + token).toString('base64');
  console.log(`
╔══════════════════════════════════════════════════════════════════════════╗
║   ThousandEyes API Simulator – v3.0 (multi-auth + OAuth 2.0)             ║
║   Listening on:   http://localhost:${PORT}                                    ║
║   API base:       http://localhost:${PORT}/v7                                 ║
║   Web Console:    http://localhost:${PORT}/                                   ║
╠══════════════════════════════════════════════════════════════════════════╣
║   THREE ways to authenticate (use whichever works in Power Platform):    ║
║                                                                          ║
║   1. Bearer token (Authorization header):                                ║
║      ${token}                ║
║                                                                          ║
║   2. Basic auth (for on-prem gateway / Basic auth dropdown):             ║
║      Username: user  (anything works)                                    ║
║      Password: ${token}        ║
║                                                                          ║
║   3. X-API-Key custom header:                                            ║
║      X-API-Key: ${token}        ║
╠══════════════════════════════════════════════════════════════════════════╣
║   OAUTH 2.0 (alternative production setup):                              ║
║   Authorize URL:  http://localhost:${PORT}/oauth/authorize                    ║
║   Token URL:      http://localhost:${PORT}/oauth/token                        ║
║   client_id     = ${oauthClient.client_id}                                 ║
║   client_secret = ${oauthClient.client_secret}      ║
╚══════════════════════════════════════════════════════════════════════════╝
`);
});
